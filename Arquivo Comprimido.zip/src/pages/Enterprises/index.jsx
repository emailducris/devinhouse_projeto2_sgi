import FormEnterprise from '../../components/FormEnterprise';
import Header from '../../components/Header';

const Enterprises = () => {
  return (
    <div className="container">
      <Header />
      <FormEnterprise />
    </div>
  );
};
export default Enterprises;
