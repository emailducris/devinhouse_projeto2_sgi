import FormProduct from '../../components/FormProduct';
import Header from '../../components/Header';

const Products = () => {
  return (
    <div className="container">
      <Header />
      <FormProduct />
    </div>
  );
};
export default Products;
