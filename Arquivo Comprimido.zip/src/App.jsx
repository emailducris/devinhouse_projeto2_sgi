import Router from './Router';
import 'leaflet/dist/leaflet.css';

const App = () => {
  return <Router />;
};

export default App;
