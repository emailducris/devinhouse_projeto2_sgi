Template do projeto 2 

- Clonar o projeto
- Fazer um npm install ou yarn
- Fazer um npm run server ou yarn start
- Fazer npm start 
